from django.contrib import admin
from .models import Categoria, Producto, Cliente

admin.site.register(Categoria)


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio', 'stock')
    actions = ['actualizar_stock_a_20']

    def actualizar_stock_a_20(modeladmin, request, queryset):
        queryset.update(stock=20)

    actualizar_stock_a_20.short_description = "Actualizar stock a 20 unidades"


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'apellidos', 'dni', 'telefono', 'direccion', 'email', 'fecha_nacimiento', 'fecha_publicacion')
